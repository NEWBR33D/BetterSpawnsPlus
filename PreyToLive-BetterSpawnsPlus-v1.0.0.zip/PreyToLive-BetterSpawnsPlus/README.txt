////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*** PreyToLives-BetterSpawnsPlus-v1.0.0 ***

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
** DISCLAIMER: This mod is NOT compatible with other ai spawn mods such as POOP, SWAG, etc. or other ai configs such as SVMs bot/raid options **
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

This mod aims to make the ai spawn more consistently throughout a raid and to prevent raids from feeling like ghost towns after 20 minutes.
    - I have customized the ai spawns for each map to continue to spawn from 45 to 60 minutes depending on the scale of the map.
    - I tried to make the ai spawn in POIs more consistently as well as keep the maps feeling always "alive" wherever you go.
    - Also, PMCs will now finally spawn in labs. :D

Besides making spawns "better" I have also included some other options to the config file that I've made to better suit how I prefer to play the game.
They are all set to how I prefer to play but feel free to edit them to your liking. The defaultConfig.json in the config folder has all the default BSG values from EFT for reference.
This is still very much a WIP so if you have any recommendations for the mod or would like to see any other options added to it please let me know and I will see what I can do.

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
** IMPORTANT: Bosses MUST be ENABLED in-game or else this mod will not work. You must only enable or disable bosses in the config file. **
** IMPORTANT: This mod already includes my other mod "AllOpenZones" so if you are already using it then you need to remove/delete it from your mods folder. **
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Below is a brief overview of what all the config file options do.

"enabled": [true/false]
    - enables the mod

"allOpenZones": [n/a]
    - enabled by default when the mod is enabled and is required for the mod to work correctly
    - this option allows pmcs and scavs to spawn in certain ai open zones that they previously could not spawn in

"allExtractionsAlwaysAvailable": [true/false]
    - all side specific (pmc or scav) exfil locations will always available to extract at

"removeExtractionRestrictions": [true/false]
    - removes extraction restrictions

"escapeTimeLimit": [integer]
    - sets the raid timer (in minutes)

"customSpawnWaves": [true/false]
    - this option enables my custom ai spawn waves for each map
    - i have made the ai to conistently spawn over a duration of 45 to 60 minutes based on the map (factory & labs are 45 min, everything else is 60 min)
    - setting the raid timer past 45 or 60 minutes is okay to do, but just know that the ai will stop spawning after 45 or 60 minutes
    - pmcs have been made to spawn seperately from scavs so now you will more likely have a chance to encounter them before they spawn kill each other

"enableBosses": [true/false]
    - please use this option to enable or disable bosses instead of the enable/disable checkbox in-game

"maxBotCap": [integer]
    - sets the maximum number of ai able to spawn on each map
    - when a map reaches a count of 25 ai it will stop spawning more ai until an ai dies
    - i recommend setting this number no higher than 30 or else fps will drop significantly

"globalLootChanceModifier": [integer/decimal]
    - this option changes the overall amount of loot in raid

"looseLootMultiplier": [integer/decimal]
    - this option changes the amount of loose loot found in raid

"staticLootMultiplier": [integer/decimal]
    - this option changes the amount of loot found in containers found in raid

"airDropsPerRaid": [integer]
    - sets the maximum number of air drops each raid
    - however it does not guarantee the set number of air drops per raid

"chanceSameFactionIsHostile": [%]
    - percent chance that bear/usec will be hostile to you

"botLevelRelativeToPlayerLevel": [integer]
    - sets the ai level based on the player level
    - the number you set is a range, for example if you are lvl 25 and the number set is 5 then the ai level will range from 20 to 30

"randomRaiderEncounters":
    "enabled": [true/false]
    "chance": [%]
    "amount": [""]
        - an experimental option i thought would make raids more dangerous/exciting
        - a number from the sequence of numbers in "amount" is chosen at random. this randomly chosen number is the number of raiders that will be spawned in

"removeArmorDegradationFromRepairs": [true/false]
    - this option prevents permanent armor degradation from repairs

"removeWeaponDegradationFromRepairs": [true/false]
    - this option prevents permanent weapon degradation from repairs

"insuranceAllowedOnAllLocations": [true/false]
    - this option allows insurance all locations
    - primarily for labs

"insuranceAllowedForAllItems": [true/false]
    - this option allows all items to be insurable

"removeGearDurabilityBurn": [true/false]
    - this options removes durability burn for weapons

"removeBulletWeaponDeterioration": [true/false]
    - this options removes bullet deterioration for weapons

"allowAllItemsToBelootable": [true/false]
    - this option allows all items to be lootable off of dead ai bodies
    - primarily allows you to loot armbands and scabbards

"allItemsUnexaminedByDefault": [true/false]
    - this option makes all items unexamined by default
    - meant for new games where some of the items are examined by default

"labsAccessKeycard":
    "removeLabsReq": [true/false]
    "maxNumberOfUses": [integer]
        - this option allows you to either completely disable the labs keycard requirement
        - or instead you can set the number of uses allowed for the labs keycard

"scavTimer": [integer]
    - sets the scav cooldown timer (in minutes)

"allowTacticalClothingForBothFactions": [true/false]
    - this option allows all tactical clothing to be avilable for both bear and usec

"removeFreeHealTrialLevelsAndRaids": [true/false]
    - this option removes the free heals you get after raids
    - for those of you that want to make the game more difficult

"healthInRaid":
    "energyLoopTime": [integer]
    "energyDecreasePerLoopTime": [integer/decimal]
    "hydrationLoopTime": [integer]
    "hydrationDecreasePerLoopTime": [integer/decimal]
        - this option changes the energy and hydration lost per minute while in raid

"healthInHideout":
    "healthRegenerationLoopTime": [integer]
    "energyRegenerationLoopTime": [integer]
    "hydrationRegenerationLoopTime": [integer]
        - this option changes the energy, hydration, and health regeneration time while in hideout

"productionTimeMultiplier": [integer/decimal]
    - this option either increases or decreases the production time in hideout

"constructionTimeMultiplier": [integer/decimal]
    - this option either increases or decreases the construction time in hideout
    - for example if the number is set to 0.025 then a construction that takes 24 hours will now take 36 minutes

"repairCostMultiplierForAllTraders": [integer/decimal]
    - this option either increases or decreases traders item repair cost
    - for example if the number is set to 0.75 then a reapir that costs 30,000 will now cost 22,500

"insuranceMultiplier": [integer/decimal]
    - this option changes the cost of insurance

"returnChancePercent": [%]
    - percent chance that a trader returns your insured items

"minReturnTime": [integer]
"maxReturnTime": [integer]
    - these set the min/max return time of insured items
    - must be a whole number, no decimals (in hours)

"repairQualityDegradation": [integer/decimal]
    - this option sets the amount of degradation applied to gear/weapons during repairs
    - setting this to zero will remove any degradation during repairs

"replaceTradersProfilePics": [true/false]
    - this option uses my custom trader profile pics that i think look better than the original
    - IMPORTANT: you need to clean the temp files in the launcher settings one time for the trader profile pictures to show

"replaceLauncherBackground": [true/false]
    - this option uses my preffered launcher background images
    - a random image will be chosen each time you restart the server and launcher
    - IMPORTANT: you need to clean the temp files in the launcher settings one time for the launcher background images to show
    - artwork created by Vlad Novikov: https://www.artstation.com/yu2673 and Eugene Shushliamin: https://www.artstation.com/geck

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////