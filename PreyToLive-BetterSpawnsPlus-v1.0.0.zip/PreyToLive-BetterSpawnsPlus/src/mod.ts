import { DependencyContainer } from "tsyringe";
import { PreAkiModLoader } from "@spt-aki/loaders/PreAkiModLoader";
import { IPostDBLoadMod } from "@spt-aki/models/external/IPostDBLoadMod";
import { IPostAkiLoadMod } from "@spt-aki/models/external/IPostAkiLoadMod";
import { ILogger } from "@spt-aki/models/spt/utils/ILogger";
import type { ConfigServer } from "@spt-aki/servers/ConfigServer";
import type { DatabaseServer } from "@spt-aki/servers/DatabaseServer";
import { ConfigTypes } from "@spt-aki/models/enums/ConfigTypes";
import { IBotConfig } from "@spt-aki/models/spt/config/IBotConfig";
import { IInRaidConfig } from "@spt-aki/models/spt/config/IInRaidConfig";
import { IInsuranceConfig } from "@spt-aki/models/spt/config/IInsuranceConfig";
import { ILocationConfig } from "@spt-aki/models/spt/config/ILocationConfig";
import { IRepairConfig } from "@spt-aki/models/spt/config/IRepairConfig";
import { Traders as eftTraders } from "@spt-aki/models/enums/Traders";
import { WildSpawnTypeNumber as sptTypes } from "@spt-aki/models/enums/WildSpawnTypeNumber";
import { ImageRouter } from "@spt-aki/routers/ImageRouter";
import * as path from "path";
import * as fs from "fs";
import pkg from "../package.json";
import config from "../config/config.json";
import pmcWavesCustoms from "../data/spawnWaves/customs.json";
import pmcWavesFactoryDay from "../data/spawnWaves/factory_day.json";
import pmcWavesFactoryNight from "../data/spawnWaves/factory_night.json";
import pmcWavesInterchange from "../data/spawnWaves/interchange.json";
import pmcWavesLabs from "../data/spawnWaves/labs.json";
import pmcWavesLighthouse from "../data/spawnWaves/lighthouse.json";
import pmcWavesReserve from "../data/spawnWaves/reserve.json";
import pmcWavesShoreline from "../data/spawnWaves/shoreline.json";
//import pmcWavesStreets from "../data/spawnWaves/streets.json";
import pmcWavesWoods from "../data/spawnWaves/woods.json";
import bossWavesCustoms from "../data/bossWaves/customs.json";
import bossWavesFactory from "../data/bossWaves/factory.json";
import bossWavesInterchange from "../data/bossWaves/interchange.json";
import bossWavesLighthouse from "../data/bossWaves/lighthouse.json";
import bossWavesReserve from "../data/bossWaves/reserve.json";
import bossWavesShoreline from "../data/bossWaves/shoreline.json";
//import bossWavesStreets from "../data/bossWaves/streets.json";
import bossWavesWoods from "../data/bossWaves/woods.json";
import randomRaiderEncounters from "../data/experimental/randomRaiderEncounters.json";

class BetterSpawnsPlus implements IPostDBLoadMod, IPostAkiLoadMod
{
    public postDBLoad(container: DependencyContainer): void
    {
        const logger: ILogger = container.resolve<ILogger>("WinstonLogger");
        const pkgName = `${pkg.author}-${pkg.name}`;

        //logger.info(`Loading: ${pkgName} ${pkg.version}${config.enabled === true ? "" : " [Disabled]"}`);

        const configsBots = container.resolve<ConfigServer>("ConfigServer").getConfig<IBotConfig>(ConfigTypes.BOT);
        const configsInraids = container.resolve<ConfigServer>("ConfigServer").getConfig<IInRaidConfig>(ConfigTypes.IN_RAID);
        const configsInsurance = container.resolve<ConfigServer>("ConfigServer").getConfig<IInsuranceConfig>(ConfigTypes.INSURANCE);
        const configsLocations = container.resolve<ConfigServer>("ConfigServer").getConfig<ILocationConfig>(ConfigTypes.LOCATION);
        const configsRepairs = container.resolve<ConfigServer>("ConfigServer").getConfig<IRepairConfig>(ConfigTypes.REPAIR);
        const databaseCustomization = container.resolve<DatabaseServer>("DatabaseServer").getTables().templates.customization;
        const databaseGlobals = container.resolve<DatabaseServer>("DatabaseServer").getTables().globals;
        const databaseHideout = container.resolve<DatabaseServer>("DatabaseServer").getTables().hideout;
        const databaseItems = container.resolve<DatabaseServer>("DatabaseServer").getTables().templates.items;
        const databaseLocations = container.resolve<DatabaseServer>("DatabaseServer").getTables().locations;
        const databaseTraders = container.resolve<DatabaseServer>("DatabaseServer").getTables().traders;

        if (config.enabled != false && typeof config.enabled === "boolean")
        {
            /* RAIDS OPTIONS */

            /* [raids][open all zones for all bot types to spawn in] */
            const locations = {
                "bigmap": "ZoneBlockPost,ZoneBlockPostSniper,ZoneBlockPostSniper3,ZoneBrige,ZoneCrossRoad,ZoneCustoms,ZoneDormitory,ZoneFactoryCenter,ZoneFactorySide,ZoneGasStation,ZoneOldAZS,ZoneScavBase,ZoneSnipeBrige,ZoneSnipeFactory,ZoneSnipeTower,ZoneTankSquare,ZoneWade",
                "interchange": "ZoneCenter,ZoneCenterBot,ZoneGoshan,ZoneIDEA,ZoneIDEAPark,ZoneOLI,ZoneOLIPark,ZonePowerStation,ZoneRoad,ZoneTrucks",
                "laboratory": "BotZoneBasement,BotZoneFloor1,BotZoneFloor2,BotZoneGate1,BotZoneGate2",
                "lighthouse": "Zone_Blockpost,Zone_Bridge,Zone_Chalet,Zone_Containers,Zone_DestroyedHouse,Zone_Hellicopter,Zone_Island,Zone_LongRoad,Zone_OldHouse,Zone_Rocks,Zone_RoofBeach,Zone_RoofContainers,Zone_RoofRocks,Zone_SniperPeak,Zone_TreatmentBeach,Zone_TreatmentContainers,Zone_TreatmentRocks,Zone_Village",
                "rezervbase": "ZoneBarrack,ZoneBunkerStorage,ZonePTOR1,ZonePTOR2,ZoneRailStrorage,ZoneSubCommand,ZoneSubStorage",
                "shoreline": "ZoneBunker,ZoneBunkeSniper,ZoneBusStation,ZoneForestGasStation,ZoneForestSpawn,ZoneForestTruck,ZoneGasStation,ZoneGreenHouses,ZoneIsland,ZoneMeteoStation,ZonePassClose,ZonePassFar,ZonePort,ZonePowerStation,ZonePowerStationSniper,ZoneRailWays,ZoneSanatorium1,ZoneSanatorium2,ZoneTunnel,ZoneStartVillage",
                "tarkovstreets": "ZoneCarShowroom,ZoneCinema,ZoneColumn,ZoneConcordia_1,ZoneConcordia_2,ZoneConcordiaParking,ZoneConstruction,ZoneFactory,ZoneHotel_1,ZoneHotel_2,ZoneSnipeBuilding,ZoneSnipeCarShowroom,ZoneSnipeCinema,ZoneSnipeSW01,ZoneSW01",
                "woods": "ZoneBigRocks,ZoneBrokenVill,ZoneClearVill,ZoneHighRocks,ZoneHouse,ZoneMiniHouse,ZoneRedHouse,ZoneRoad,ZoneScavBase2,ZoneWoodCutter"
            }

            for (const location in locations)
            {
                databaseLocations[location].base.OpenZones = locations[location];
            }

            /* [raids][enable bosses by default] */
            const bossEnabled = true;
            configsInraids.raidMenuSettings.bossEnabled = bossEnabled;

            /* [raids][remove extraction restrictions] */
            if (config.raids.locations.removeExtractionRestrictions)
            {
                for (const i in databaseLocations)
                {
                    if (i !== "base")
                    {
                        for (const x in databaseLocations[i].base.exits)
                        {
                            if (databaseLocations[i].base.exits[x].Name !== "EXFIL_Train" && !databaseLocations[i].base.exits[x].Name.includes("lab") || databaseLocations[i].base.exits[x].Name === "lab_Vent")
                            {
                                if (databaseLocations[i].base.exits[x].RequiredSlot)
                                {
                                    delete databaseLocations[i].base.exits[x].RequiredSlot;
                                }
                                databaseLocations[i].base.exits[x].PassageRequirement = "None";
                                databaseLocations[i].base.exits[x].ExfiltrationType = "Individual";
                                databaseLocations[i].base.exits[x].Id = "";
                                databaseLocations[i].base.exits[x].Count = 0;
                                databaseLocations[i].base.exits[x].RequirementTip = "";
                            }

                            /* [raids][make all extractions always available] */
                            if (config.raids.locations.allExtractionsAlwaysAvailable)
                            {
                                if (databaseLocations[i].base.exits[x].Name !== "EXFIL_Train")
                                {
                                    databaseLocations[i].base.exits[x].Chance = 100;
                                }
                            }
                        }
                    }
                }
            }

            /* [raids][locations][customs] */

            // [change waves and boss locations spawns for PMCs, scavs, raiders, rogues, etc.]
            if (config.raids.locations.customs.customSpawnWaves)
            {
                databaseLocations.bigmap.base.waves = [];
                databaseLocations.bigmap.base.BossLocationSpawn = pmcWavesCustoms.BossLocationSpawn;

                if (config.raids.locations.customs.enableBosses)
                {
                    const bossesCustoms = bossWavesCustoms.BossLocationSpawn;
                    for (const boss in bossesCustoms)
                    {
                        pmcWavesCustoms.BossLocationSpawn.push(bossesCustoms[boss]);
                    }
                }
            }
            // [change map exit time]{time (in minutes)}
            databaseLocations.bigmap.base.exit_access_time = config.raids.locations.customs.escapeTimeLimit + 20;
            databaseLocations.bigmap.base.EscapeTimeLimit = config.raids.locations.customs.escapeTimeLimit;
            // [set the max number of bots to exist on the entire map at one time]
            configsBots.maxBotCap.customs = config.raids.locations.customs.maxBotCap;
            // [global loot modifier]
            databaseLocations.bigmap.base.GlobalLootChanceModifier = config.raids.locations.customs.globalLootChanceModifier;
            // [loose loot multiplier]
            configsLocations.looseLootMultiplier.bigmap = config.raids.locations.customs.looseLootMultiplier;
            // [static loot multiplier]
            configsLocations.staticLootMultiplier.bigmap = config.raids.locations.customs.staticLootMultiplier;
            // [change airdrop end time and max amount of airdrops per raid based on raid time limit]{time (in secs)}
            databaseLocations.bigmap.base.AirdropParameters["PlaneAirdropEnd"] = config.raids.locations.customs.escapeTimeLimit * 60 * 0.75;
            databaseLocations.bigmap.base.AirdropParameters["PlaneAirdropMax"] = config.raids.locations.customs.airDropsPerRaid;

            /* [raids][locations][factory] */

            // [change waves and boss locations spawns for PMCs, scavs, raiders, rogues, etc.]
            if (config.raids.locations.factory.customSpawnWaves)
            {
                databaseLocations.factory4_day.base.waves = [];
                databaseLocations.factory4_night.base.waves = [];
                databaseLocations.factory4_day.base.BossLocationSpawn = pmcWavesFactoryDay.BossLocationSpawn;
                databaseLocations.factory4_night.base.BossLocationSpawn = pmcWavesFactoryNight.BossLocationSpawn;

                if (config.raids.locations.factory.enableBosses)
                {
                    const bossesFactory = bossWavesFactory.BossLocationSpawn;
                    for (const i in bossesFactory)
                    {
                        pmcWavesFactoryDay.BossLocationSpawn.push(bossesFactory[i]);
                        pmcWavesFactoryNight.BossLocationSpawn.push(bossesFactory[i]);
                    }
                }
            }
            // [change map exit time]{time (in minutes)}
            databaseLocations.factory4_day.base.exit_access_time = config.raids.locations.factory.escapeTimeLimit + 20;
            databaseLocations.factory4_day.base.EscapeTimeLimit = config.raids.locations.factory.escapeTimeLimit;
            databaseLocations.factory4_night.base.exit_access_time = config.raids.locations.factory.escapeTimeLimit + 20;
            databaseLocations.factory4_night.base.EscapeTimeLimit = config.raids.locations.factory.escapeTimeLimit;
            // [set the max number of bots to exist on the entire map at one time]
            configsBots.maxBotCap.factory = config.raids.locations.factory.maxBotCap;
            // [global loot modifier]
            databaseLocations.factory4_day.base.GlobalLootChanceModifier = config.raids.locations.factory.globalLootChanceModifier;
            databaseLocations.factory4_night.base.GlobalLootChanceModifier = config.raids.locations.factory.globalLootChanceModifier;
            // [loose loot multiplier]
            configsLocations.looseLootMultiplier.factory4_day = config.raids.locations.factory.looseLootMultiplier;
            configsLocations.looseLootMultiplier.factory4_night = config.raids.locations.factory.looseLootMultiplier;
            // [static loot multiplier]
            configsLocations.staticLootMultiplier.factory4_day = config.raids.locations.factory.staticLootMultiplier;
            configsLocations.staticLootMultiplier.factory4_night = config.raids.locations.factory.staticLootMultiplier;

            /* [raids][locations][interchange] */

            // [change waves and boss locations spawns for PMCs, scavs, raiders, rogues, etc.]
            if (config.raids.locations.interchange.customSpawnWaves)
            {
                databaseLocations.interchange.base.waves = [];
                databaseLocations.interchange.base.BossLocationSpawn = pmcWavesInterchange.BossLocationSpawn;

                if (config.raids.locations.interchange.enableBosses)
                {
                    const bossesInterchange = bossWavesInterchange.BossLocationSpawn;
                    for (const boss in bossesInterchange)
                    {
                        pmcWavesInterchange.BossLocationSpawn.push(bossesInterchange[boss]);
                    }
                }
            }
            // [change map exit time]{time (in minutes)}
            databaseLocations.interchange.base.exit_access_time = config.raids.locations.interchange.escapeTimeLimit + 20;
            databaseLocations.interchange.base.EscapeTimeLimit = config.raids.locations.interchange.escapeTimeLimit;
            // [set the max number of bots to exist on the entire map at one time]
            configsBots.maxBotCap.interchange = config.raids.locations.interchange.maxBotCap;
            // [global loot modifier]
            databaseLocations.interchange.base.GlobalLootChanceModifier = config.raids.locations.interchange.globalLootChanceModifier;
            // [loose loot multiplier]
            configsLocations.looseLootMultiplier.interchange = config.raids.locations.interchange.looseLootMultiplier;
            // [static loot multiplier]
            configsLocations.staticLootMultiplier.interchange = config.raids.locations.interchange.staticLootMultiplier;
            // [change airdrop end time and max amount of airdrops per raid based on raid time limit]{time (in secs)}
            databaseLocations.interchange.base.AirdropParameters["PlaneAirdropEnd"] = config.raids.locations.interchange.escapeTimeLimit * 60 * 0.75;
            databaseLocations.interchange.base.AirdropParameters["PlaneAirdropMax"] = config.raids.locations.interchange.airDropsPerRaid;

            /* [raids][locations][labs] */

            // [change waves and boss locations spawns for PMCs, scavs, raiders, rogues, etc.]
            databaseLocations.laboratory.base.waves = [];
            databaseLocations.laboratory.base.BossLocationSpawn = pmcWavesLabs.BossLocationSpawn;
            // [change map exit time]{time (in minutes)}
            databaseLocations.laboratory.base.exit_access_time = config.raids.locations.labs.escapeTimeLimit + 20;
            databaseLocations.laboratory.base.EscapeTimeLimit = config.raids.locations.labs.escapeTimeLimit;
            // [set the max number of bots to exist on the entire map at one time]
            configsBots.maxBotCap.laboratory = config.raids.locations.labs.maxBotCap;
            // [global loot modifier]
            databaseLocations.laboratory.base.GlobalLootChanceModifier = config.raids.locations.labs.globalLootChanceModifier;
            // [loose loot multiplier]
            configsLocations.looseLootMultiplier.laboratory = config.raids.locations.labs.looseLootMultiplier;
            // [static loot multiplier]
            configsLocations.staticLootMultiplier.laboratory = config.raids.locations.labs.staticLootMultiplier;

            /* [raids][locations][lighthouse] */

            // [change waves and boss locations spawns for PMCs, scavs, raiders, rogues, etc.]
            if (config.raids.locations.lighthouse.customSpawnWaves)
            {
                databaseLocations.lighthouse.base.waves = [];
                databaseLocations.lighthouse.base.BossLocationSpawn = pmcWavesLighthouse.BossLocationSpawn;

                if (config.raids.locations.lighthouse.enableBosses)
                {
                    const bossesLighthouse = bossWavesLighthouse.BossLocationSpawn;
                    for (const boss in bossesLighthouse)
                    {
                        pmcWavesLighthouse.BossLocationSpawn.push(bossesLighthouse[boss]);
                    }
                }
            }
            // [change map exit time]{time (in minutes)}
            databaseLocations.lighthouse.base.exit_access_time = config.raids.locations.lighthouse.escapeTimeLimit + 20;
            databaseLocations.lighthouse.base.EscapeTimeLimit = config.raids.locations.lighthouse.escapeTimeLimit;
            // [set the max number of bots to exist on the entire map at one time]
            configsBots.maxBotCap.lighthouse = config.raids.locations.lighthouse.maxBotCap;
            // [global loot modifier]
            databaseLocations.lighthouse.base.GlobalLootChanceModifier = config.raids.locations.lighthouse.globalLootChanceModifier;
            // [loose loot multiplier]
            configsLocations.looseLootMultiplier.lighthouse = config.raids.locations.lighthouse.looseLootMultiplier;
            // [static loot multiplier]
            configsLocations.staticLootMultiplier.lighthouse = config.raids.locations.lighthouse.staticLootMultiplier;
            // [change airdrop end time and max amount of airdrops per raid based on raid time limit]{time (in secs)}
            databaseLocations.lighthouse.base.AirdropParameters["PlaneAirdropEnd"] = config.raids.locations.lighthouse.escapeTimeLimit * 60 * 0.75;
            databaseLocations.lighthouse.base.AirdropParameters["PlaneAirdropMax"] = config.raids.locations.lighthouse.airDropsPerRaid;
            // [change armored train exfil time]{time (in secs)}
            for (const exfil in databaseLocations.lighthouse.base.exits)
            {
                if (databaseLocations.lighthouse.base.exits[exfil].Name == "EXFIL_Train")
                {
                    databaseLocations.lighthouse.base.exits[exfil].MinTime = config.raids.locations.lighthouse.escapeTimeLimit * 60 * 0.5;
                    databaseLocations.lighthouse.base.exits[exfil].MaxTime = (config.raids.locations.lighthouse.escapeTimeLimit * 60) - 300;
                }
            }

            /* [raids][locations][reserve] */

            // [change waves and boss locations spawns for PMCs, scavs, raiders, rogues, etc.]
            if (config.raids.locations.reserve.customSpawnWaves)
            {
                databaseLocations.rezervbase.base.waves = [];
                databaseLocations.rezervbase.base.BossLocationSpawn = pmcWavesReserve.BossLocationSpawn;
                
                if (config.raids.locations.reserve.enableBosses)
                {
                    const bossesReserve = bossWavesReserve.BossLocationSpawn;
                    for (const boss in bossesReserve)
                    {
                        pmcWavesReserve.BossLocationSpawn.push(bossesReserve[boss]);
                    }
                }
            }
            // [change map exit time]{time (in minutes)}
            databaseLocations.rezervbase.base.exit_access_time = config.raids.locations.reserve.escapeTimeLimit + 20;
            databaseLocations.rezervbase.base.EscapeTimeLimit = config.raids.locations.reserve.escapeTimeLimit;
            // [set the max number of bots to exist on the entire map at one time]
            configsBots.maxBotCap.rezervbase = config.raids.locations.reserve.maxBotCap;
            // [global loot modifier]
            databaseLocations.rezervbase.base.GlobalLootChanceModifier = config.raids.locations.reserve.globalLootChanceModifier;
            // [loose loot multiplier]
            configsLocations.looseLootMultiplier.rezervbase = config.raids.locations.reserve.looseLootMultiplier;
            // [static loot multiplier]
            configsLocations.staticLootMultiplier.rezervbase = config.raids.locations.reserve.staticLootMultiplier;
            // [change airdrop end time and max amount of airdrops per raid based on raid time limit]{time (in secs)}
            databaseLocations.rezervbase.base.AirdropParameters["PlaneAirdropEnd"] = config.raids.locations.reserve.escapeTimeLimit * 60 * 0.75;
            databaseLocations.rezervbase.base.AirdropParameters["PlaneAirdropMax"] = config.raids.locations.reserve.airDropsPerRaid;
            // [change armored train exfil time]{time (in secs)}
            for (const exfil in databaseLocations.rezervbase.base.exits)
            {
                if (databaseLocations.rezervbase.base.exits[exfil].Name == "EXFIL_Train")
                {
                    databaseLocations.rezervbase.base.exits[exfil].MinTime = config.raids.locations.reserve.escapeTimeLimit * 60 * 0.5;
                    databaseLocations.rezervbase.base.exits[exfil].MaxTime = (config.raids.locations.reserve.escapeTimeLimit * 60) - 300;
                }
            }

            /* [raids][locations][shoreline] */

            // [change waves and boss locations spawns for PMCs, scavs, raiders, rogues, etc.]
            if (config.raids.locations.shoreline.customSpawnWaves)
            {
                databaseLocations.shoreline.base.waves = [];
                databaseLocations.shoreline.base.BossLocationSpawn = pmcWavesShoreline.BossLocationSpawn;

                if (config.raids.locations.shoreline.enableBosses !== false && typeof config.raids.locations.shoreline.enableBosses === "boolean")
                {
                    const bossesShoreline = bossWavesShoreline.BossLocationSpawn;
                    for (const boss in bossesShoreline)
                    {
                        pmcWavesShoreline.BossLocationSpawn.push(bossesShoreline[boss]);
                    }
                }
            }
            // [change map exit time]{time (in minutes)}
            databaseLocations.shoreline.base.exit_access_time = config.raids.locations.shoreline.escapeTimeLimit + 20;
            databaseLocations.shoreline.base.EscapeTimeLimit = config.raids.locations.shoreline.escapeTimeLimit;
            // [set the max number of bots to exist on the entire map at one time]
            configsBots.maxBotCap.shoreline = config.raids.locations.shoreline.maxBotCap;
            // [global loot modifier]
            databaseLocations.shoreline.base.GlobalLootChanceModifier = config.raids.locations.shoreline.globalLootChanceModifier;
            // [loose loot multiplier]
            configsLocations.looseLootMultiplier.shoreline = config.raids.locations.shoreline.looseLootMultiplier;
            // [static loot multiplier]
            configsLocations.staticLootMultiplier.shoreline = config.raids.locations.shoreline.staticLootMultiplier;
            // [change airdrop end time and max amount of airdrops per raid based on raid time limit]{time (in secs)}
            databaseLocations.shoreline.base.AirdropParameters["PlaneAirdropEnd"] = config.raids.locations.shoreline.escapeTimeLimit * 60 * 0.75;
            databaseLocations.shoreline.base.AirdropParameters["PlaneAirdropMax"] = config.raids.locations.shoreline.airDropsPerRaid;
            
            /* [raids][locations][streets of tarkov] (not available for SPT v3.4.1)

            // [change waves and boss locations spawns for PMCs, scavs, raiders, rogues, etc.]
            if (config.raids.locations.streetsOfTarkov.customSpawnWaves)
            {
                databaseLocations.tarkovstreets.base.waves = [];
                databaseLocations.tarkovstreets.base.BossLocationSpawn = streetsOfTarkov.BossLocationSpawn;

                if (config.raids.locations.streetsOfTarkov.enableBosses)
                {
                    const bossesStreets = bossWavesStreets.BossLocationSpawn;
                    for (const boss in bossesStreets)
                    {
                        streetsOfTarkov.BossLocationSpawn.push(bossesStreets[boss]);
                    }
                }
            }
            // [change map exit time]{time (in minutes)}
            databaseLocations.tarkovstreets.base.exit_access_time = config.raids.locations.streetsOfTarkov.escapeTimeLimit + 20;
            databaseLocations.tarkovstreets.base.EscapeTimeLimit = config.raids.locations.streetsOfTarkov.escapeTimeLimit;
            // [set the max number of bots to exist on the entire map at one time]
            configsBots.maxBotCap.tarkovstreets = config.raids.locations.streetsOfTarkov.maxBotCap;
            // [global loot modifier]
            databaseLocations.tarkovstreets.base.GlobalLootChanceModifier = config.raids.locations.streetsOfTarkov.globalLootChanceModifier;
            // [loose loot multiplier]
            configsLocations.looseLootMultiplier.tarkovstreets = config.raids.locations.streetsOfTarkov.looseLootMultiplier;
            // [static loot multiplier]
            configsLocations.staticLootMultiplier.tarkovstreets = config.raids.locations.streetsOfTarkov.staticLootMultiplier;
            // [change airdrop end time and max]{time (in secs)}
            databaseLocations.tarkovstreets.base.AirdropParameters["PlaneAirdropEnd"] = config.raids.locations.streetsOfTarkov.escapeTimeLimit * 60 * 0.75;
            databaseLocations.tarkovstreets.base.AirdropParameters["PlaneAirdropMax"] = config.raids.locations.streetsOfTarkov.airDropsPerRaid;

            */

            /* [raids][locations][woods] */

            // [change waves and boss locations spawns for PMCs, scavs, raiders, rogues, etc.]
            if (config.raids.locations.woods.customSpawnWaves)
            {
                databaseLocations.woods.base.waves = [];
                databaseLocations.woods.base.BossLocationSpawn = pmcWavesWoods.BossLocationSpawn;

                if (config.raids.locations.woods.enableBosses)
                {
                    const bossesWoods = bossWavesWoods.BossLocationSpawn;
                    for (const boss in bossesWoods)
                    {
                        pmcWavesWoods.BossLocationSpawn.push(bossesWoods[boss]);
                    }
                }
            }
            // [change map exit time]{time (in minutes)}
            databaseLocations.woods.base.exit_access_time = config.raids.locations.woods.escapeTimeLimit + 20;
            databaseLocations.woods.base.EscapeTimeLimit = config.raids.locations.woods.escapeTimeLimit;
            // [set the max number of bots to exist on the entire map at one time]
            configsBots.maxBotCap.woods = config.raids.locations.woods.maxBotCap;
            // [global loot modifier]
            databaseLocations.woods.base.GlobalLootChanceModifier = config.raids.locations.woods.globalLootChanceModifier;
            // [loose loot multiplier]
            configsLocations.looseLootMultiplier.woods = config.raids.locations.woods.looseLootMultiplier;
            // [static loot multiplier]
            configsLocations.staticLootMultiplier.woods = config.raids.locations.woods.staticLootMultiplier;
            // [change airdrop end time and max amount of airdrops per raid based on raid time limit]{time (in secs)}
            databaseLocations.woods.base.AirdropParameters["PlaneAirdropEnd"] = config.raids.locations.woods.escapeTimeLimit * 60 * 0.75;
            databaseLocations.woods.base.AirdropParameters["PlaneAirdropMax"] = config.raids.locations.woods.airDropsPerRaid;

            /* [raids][experimental][random raider encounters] */
            if (config.raids.experimental.randomRaiderEncounters.enabled)
            {
                // [chance of random raider encounters]{(%)}
                randomRaiderEncounters.randomRaidersCustoms[0].BossChance = config.raids.experimental.randomRaiderEncounters.chance;
                randomRaiderEncounters.randomRaidersInterchange[0].BossChance = config.raids.experimental.randomRaiderEncounters.chance;
                randomRaiderEncounters.randomRaidersLighthouse[0].BossChance = config.raids.experimental.randomRaiderEncounters.chance;
                randomRaiderEncounters.randomRaidersReserve[0].BossChance = config.raids.experimental.randomRaiderEncounters.chance;
                randomRaiderEncounters.randomRaidersShoreline[0].BossChance = config.raids.experimental.randomRaiderEncounters.chance;
                randomRaiderEncounters.randomRaidersWoods[0].BossChance = config.raids.experimental.randomRaiderEncounters.chance;
                // [amount of raiders in each encounter]{(a number is chosen at random from the sequence in the "config.json")}
                randomRaiderEncounters.randomRaidersCustoms[0].BossEscortAmount = config.raids.experimental.randomRaiderEncounters.amount;
                randomRaiderEncounters.randomRaidersInterchange[0].BossEscortAmount = config.raids.experimental.randomRaiderEncounters.amount;
                randomRaiderEncounters.randomRaidersLighthouse[0].BossEscortAmount = config.raids.experimental.randomRaiderEncounters.amount;
                randomRaiderEncounters.randomRaidersReserve[0].BossEscortAmount = config.raids.experimental.randomRaiderEncounters.amount;
                randomRaiderEncounters.randomRaidersShoreline[0].BossEscortAmount = config.raids.experimental.randomRaiderEncounters.amount;
                randomRaiderEncounters.randomRaidersWoods[0].BossEscortAmount = config.raids.experimental.randomRaiderEncounters.amount;
                // [add random raider encounters for each location]
                pmcWavesCustoms.BossLocationSpawn.push(randomRaiderEncounters.randomRaidersCustoms[0]);
                pmcWavesInterchange.BossLocationSpawn.push(randomRaiderEncounters.randomRaidersInterchange[0]);
                pmcWavesLighthouse.BossLocationSpawn.push(randomRaiderEncounters.randomRaidersLighthouse[0]);
                pmcWavesReserve.BossLocationSpawn.push(randomRaiderEncounters.randomRaidersReserve[0]);
                pmcWavesShoreline.BossLocationSpawn.push(randomRaiderEncounters.randomRaidersShoreline[0]);
                pmcWavesWoods.BossLocationSpawn.push(randomRaiderEncounters.randomRaidersWoods[0]);
            }

            /* [raids][bots][chance that a scav, cursed scav, raider, or rogue spawns as a PMC]{(%)} */
            const pmcConvertChance = {
                "convertIntoPmcChance": {
                    "assault": {
                        "min": 0,
                        "max": 0
                    },
                    "cursedassault": {
                        "min": 0,
                        "max": 0
                    },
                    "pmcbot": {
                        "min": 0,
                        "max": 0
                    },
                    "exusec": {
                        "min": 0,
                        "max": 0
                    }
                }  
            }

            const botTypes = [
                "assault",
                "cursedassault",
                "pmcbot",
                "exusec"
            ];

            botTypes.forEach(function(botType)
            {
                configsBots.pmc.convertIntoPmcChance[botType].min = pmcConvertChance.convertIntoPmcChance[botType].min;
                configsBots.pmc.convertIntoPmcChance[botType].max = pmcConvertChance.convertIntoPmcChance[botType].max;
            });

            /* [raids][bots][chance that a PMC will spawn with a different bot brain type]{(weighted)} */
            const bearTypeChance = {
                "pmcBotType": {
                    "bossKilla": 4,
                    "bossKnight": 3,
                    "bossGluhar": 1,
                    "bossSanitar": 5,
                    "bossTagilla": 1,
                    "followerGluharAssault": 1,
                    "followerBully": 1,
                    "followerBigPipe": 4,
                    "followerSanitar": 1,
                    "assault": 4,
                    "cursedAssault": 2,
                    "exUsec": 2,
                    "pmcBot": 5
                }
            }

            const usecTypeChance = {
                "pmcBotType": {
                    "bossKilla": 4,
                    "bossKnight": 3,
                    "bossGluhar": 1,
                    "bossSanitar": 5,
                    "bossTagilla": 1,
                    "followerGluharAssault": 1,
                    "followerBully": 1,
                    "followerBigPipe": 4,
                    "followerSanitar": 1,
                    "assault": 4,
                    "cursedAssault": 2,
                    "exUsec": 2,
                    "pmcBot": 5
                }
            }

            const maps = [
                "bigmap",
                "factory4_day",
                "factory4_night",
                "interchange",
                "laboratory",
                "lighthouse",
                "rezervbase",
                "shoreline",
                "woods"
            ];
            
            maps.forEach(function(map)
            {
                configsBots.pmc.pmcType.sptbear[map] = bearTypeChance.pmcBotType;
                configsBots.pmc.pmcType.sptusec[map] = usecTypeChance.pmcBotType;
            });

            /* [raids][bots][chance that a PMCs flashlight or laser will be turned on]{(%)} */
            configsBots.equipment.pmc.lightLaserIsActiveChancePercent = 50;

            /* [raids][bots][generate a larger number of preset batches for Usec and Bear] */
            configsBots.presetBatch[sptTypes.SPTUSEC] = 40;
            configsBots.presetBatch[sptTypes.SPTBEAR] = 40;
            configsBots.botGenerationBatchSizePerType = 20;

            /* [raids][bots][chance that a PMC of the same faction will be hostile to player]{(%)} */
            configsBots.pmc.chanceSameSideIsHostilePercent = config.raids.bots.chanceSameFactionIsHostile;

            /* [raids][bots][bot level relative to player level]{(+/- player level)} */
            configsBots.pmc.botRelativeLevelDeltaMax = config.raids.bots.botLevelRelativeToPlayerLevel;
            
            /* ITEMS OPTIONS */

            /* [items][repairs][remove armor degradation from repairs] */
            if (config.items.repairs.removeArmorDegradationFromRepairs)
            {
                for (const armor in databaseGlobals.config.ArmorMaterials)
                {
                    databaseGlobals.config.ArmorMaterials[armor].MinRepairDegradation = 0;
                    databaseGlobals.config.ArmorMaterials[armor].MaxRepairDegradation = 0;
                    databaseGlobals.config.ArmorMaterials[armor].MinRepairKitDegradation = 0;
                    databaseGlobals.config.ArmorMaterials[armor].MaxRepairKitDegradation = 0;
                }
            }

            /* [items][repairs][remove weapon degradation from repairs] */
            if (config.items.repairs.removeWeaponDegradationFromRepairs)
            {
                for (const weapon in databaseItems)
                {
                    if (databaseItems[weapon]._props.MaxRepairDegradation !== undefined && databaseItems[weapon]._props.MaxRepairKitDegradation !== undefined)
                    {
                        this.itemData(container, weapon, "MinRepairDegradation", 0);
                        this.itemData(container, weapon, "MaxRepairDegradation", 0);
                        this.itemData(container, weapon, "MinRepairKitDegradation", 0);
                        this.itemData(container, weapon, "MaxRepairKitDegradation", 0);
                    }
                }
            }

            /* [items][insurance][allow insurance for all locations] */
            if (config.items.insurance.insuranceAllowedOnAllLocations)
            {
                maps.forEach(function(map)
                {
                    databaseLocations[map].base.Insurance = true;
                });
            }

            for (const id in databaseItems)
            {
                const base = databaseItems[id];

                if (!this.getId([id]))
                {
                    /* [items][insurance[allow insurance for all items] */
                    if (config.items.insurance.insuranceAllowedForAllItems && base._props.IsAlwaysAvailableForInsurance !== undefined) 
                    {
                        const insure = true;
                        this.itemData(container, id, "IsAlwaysAvailableForInsurance", insure);
                    }

                    /* [items][gear][remove durability burn for all gear] */
                    if (config.items.gear.removeWeaponDurabilityBurn && base._props.DurabilityBurnModificator)
                    {
                        const durabilityBurnMod = 0;
                        this.itemData(container, id, "DurabilityBurnModificator", durabilityBurnMod);
                    }

                    /* [items][weapons][remove deterioration for all weapons] */
                    if (config.items.gear.removeBulletWeaponDeterioration && base._props.Deterioration)
                    {
                        const deteriorationMod = 0;
                        this.itemData(container, id, "Deterioration", deteriorationMod);
                    }

                    /* [items][allow all items to be lootable] */
                    if (config.items.allowAllItemsToBelootable && base._props.Unlootable !== undefined)
                    {
                        const unlootable = false;
                        this.itemData(container, id, "Unlootable", unlootable);
                    }

                    /* [items][make all items unexamined by default] */
                    if (config.items.allItemsUnexaminedByDefault && base._props.ExaminedByDefault !== undefined)
                    {
                        const examined = false;
                        this.itemData(container, id, "ExaminedByDefault", examined);
                    }
                }
            }

            /* [items][labs access keycard][remove the keycard requirement for access to labs] */
            if (config.items.keys.labsAccessKeycard.removeLabsReq)
            {
                databaseLocations.laboratory.base.AccessKeys = [];
            }

            /* [items][labs access keycard][change the maximum number of uses allowed for the lab access keycard] */
            const labsAccessKeycard = databaseItems["5c94bbff86f7747ee735c08f"];
            labsAccessKeycard._props.MaximumNumberOfUsage = config.items.keys.labsAccessKeycard.maxNumberOfUses;

            /* PLAYER OPTIONS */

            /* [player][scav cooldown]{time (in minutes)} */
            databaseGlobals.config.SavagePlayCooldown = config.player.scavTimer * 60;
            
            /* [player][allow all tactical clothing for both USEC and BEAR] */
            if (config.player.allowTacticalClothingForBothFactions)
            {
                for (const customization in databaseCustomization)
                {
                    const customizationData = databaseCustomization[customization]
                    if (customizationData._parent === "5cd944d01388ce000a659df9" || customizationData._parent === "5cd944ca1388ce03a44dc2a4")
                    {
                        customizationData._props.Side = ["Usec", "Bear"];
                    }
                }
            }

            /* [player][remove free heals after raids and trial levels/raids] */
            if (config.player.removeFreeHealTrialLevelsAndRaids)
            {   
                databaseGlobals.config.Health.HealPrice.TrialLevels = 0;
                databaseGlobals.config.Health.HealPrice.TrialRaids = 0;
            }

            /* [player][energy & hydration damage and looptime while in a raid]{looptime (in minutes)} */
            databaseGlobals.config.Health.Effects.Existence.EnergyLoopTime = config.player.healthInRaid.energyLoopTime * 60;
            databaseGlobals.config.Health.Effects.Existence.EnergyDamage = config.player.healthInRaid.energyDecreasePerLoopTime;
            databaseGlobals.config.Health.Effects.Existence.HydrationLoopTime = config.player.healthInRaid.hydrationLoopTime * 60;
            databaseGlobals.config.Health.Effects.Existence.HydrationDamage = config.player.healthInRaid.hydrationDecreasePerLoopTime;

            /* [player][health, energy, & hydration regeneration looptime while in the hideout/menu]{looptime (in minutes)} */
            databaseGlobals.config.Health.Effects.Regeneration.LoopTime = config.player.healthInHideout.healthRegenerationLoopTime;
            databaseGlobals.config.Health.Effects.Regeneration.Energy = config.player.healthInHideout.energyRegenerationLoopTime;
            databaseGlobals.config.Health.Effects.Regeneration.Hydration = config.player.healthInHideout.hydrationRegenerationLoopTime;

            /* HIDEOUT OPTIONS */

            /* [hideout][production time multiplier] */
            const productionMultiplier = config.hideout.productionTimeMultiplier;

            for (const data in databaseHideout.production)
            {
                const productionData = databaseHideout.production[data];

                if (this.getId([productionData._id]) === false)
                {
                    if (!productionData.continuous && productionData.productionTime > 1)
                    {
                        productionData.productionTime = productionData.productionTime*productionMultiplier;
                    }
                }
            }

            for (const data in databaseHideout.scavcase)
            {
                const scavcaseData = databaseHideout.scavcase[data];

                if (this.getId([scavcaseData._id]) === false)
                {
                    if (scavcaseData.ProductionTime > 1)
                    {
                        scavcaseData.ProductionTime = scavcaseData.ProductionTime*productionMultiplier;
                    }
                }
            }

            /* [hideout][construction time multiplier] */
            const constructionMultiplier = config.hideout.constructionTimeMultiplier;

            for (const data in databaseHideout.areas)
            {
                const areaData = databaseHideout.areas[data];

                if (this.getId([areaData._id]) === false)
                {
                    for (const i in areaData.stages)
                    {
                        if (areaData.stages[i].constructionTime > 0)
                        {
                            areaData.stages[i].constructionTime = areaData.stages[i].constructionTime*constructionMultiplier;
                        }
                    }
                }
            }

            /* TRADERS OPTIONS */

            /* [traders][repairs][trader item repair cost mulitiplier] */
            configsRepairs.priceMultiplier = config.traders.repairCostMultiplierForAllTraders;

            /* [traders][insurance][change insurance for prapor]{price multiplier, return chance (%), min/max return time (in hours)} */
            configsInsurance.insuranceMultiplier[eftTraders.PRAPOR] = config.traders.prapor.insurance.insuranceMultiplier;
            configsInsurance.returnChancePercent[eftTraders.PRAPOR] = config.traders.prapor.insurance.returnChancePercent;
            databaseTraders[eftTraders.PRAPOR].base.insurance.min_return_hour = config.traders.prapor.insurance.minReturnTime;
            databaseTraders[eftTraders.PRAPOR].base.insurance.max_return_hour = config.traders.prapor.insurance.maxReturnTime;

            /* [traders][insurance][change insurance for therapist]{price multiplier, return chance (%), min/max return time (in hours)} */
            configsInsurance.insuranceMultiplier[eftTraders.THERAPIST] = config.traders.therapist.insurance.insuranceMultiplier;
            configsInsurance.returnChancePercent[eftTraders.THERAPIST] = config.traders.therapist.insurance.returnChancePercent;
            databaseTraders[eftTraders.THERAPIST].base.insurance.min_return_hour = config.traders.therapist.insurance.minReturnTime;
            databaseTraders[eftTraders.THERAPIST].base.insurance.max_return_hour = config.traders.therapist.insurance.maxReturnTime;

            /* [traders][repairs][trader item repair quality modifiers] */
            databaseTraders[eftTraders.MECHANIC].base.repair.quality = config.traders.mechanic.repairs.repairQualityDegradation;
            databaseTraders[eftTraders.PRAPOR].base.repair.quality = config.traders.prapor.repairs.repairQualityDegradation;
            databaseTraders[eftTraders.SKIER].base.repair.quality = config.traders.skier.repairs.repairQualityDegradation;
        }
        else
        {
            return;
        }
    }

    public postAkiLoad(container: DependencyContainer): void
    {
        const filename = path.basename(path.dirname(__dirname.split('/').pop()));
        const filepath = `${container.resolve<PreAkiModLoader>("PreAkiModLoader").getModPath(filename)}res/`;

        fs.readdir(filepath, (err, files) => 
        {
            files.forEach(file => 
            {
                /* MISC */

                /* [misc][replace trader profile pictures] */
                const imageId = file.split('/').pop().split('.').shift();

                if (config.misc.replaceTradersProfilePics)
                {  
                    container.resolve<ImageRouter>("ImageRouter").addRoute(`/files/trader/avatar/${imageId}`,`${filepath}${imageId}.${"jpg"}`);
                }

                /* [misc][replace the original launcher background with a random background] */
                const imageArray = [
                    "eft00","eft01","eft02","eft03","eft04","eft05","eft06","eft07","eft08","eft09","eft10","eft11","eft12","eft13",
                    "eft14","eft15","eft16","eft17","eft18","eft19","eft20","eft21","eft22","eft23","eft24","eft25","eft26","eft27"
                ];
                const random = Math.floor(Math.random() * imageArray.length);
                
                if (config.misc.replaceLauncherBackground)
                {  
                    container.resolve<ImageRouter>("ImageRouter").addRoute(`/files/launcher/${imageId}`,`${filepath}${imageArray[random]}.${"jpg"}`);
                }
            });
        });
    }

    private itemData(container: DependencyContainer, id: string, data: string, value: any): void
    {
        const databaseItems = container.resolve<DatabaseServer>("DatabaseServer").getTables().templates.items;
        databaseItems[id]._props[data] = value;
    }

    private idArray = [];

    private getId(id: string[]): boolean
    {
        if (this.idArray.length > 0) 
        {
            for (const isId in this.idArray) 
            {
                if (id.includes(this.idArray[isId]))
                {
                    return true;
                } 
                else 
                {
                    return false;
                }
            }
        } 
        else 
        {
            return false;
        }
    }
}

module.exports = { mod: new BetterSpawnsPlus() };